<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\categories;
use Image;

class ProductController extends Controller
{
     function index(){
        $all_Products = Product::orderBy('id','desc')->paginate(4);
        // ->paginate(2) পেজিনেশন দেওয়ার জনে এবং front এ ও কিছু লিখতে হিবে

		$deteted_product_show = Product::onlyTrashed()->get();
		// ডিলিট করা ডাটাগুলো দেখানোর জনে

		$categories = categories::all();
		
        return view('Product.AddNewProduct',compact('all_Products','deteted_product_show','categories'));
    }

// ডিলিট করা ডাটা গুলো Restore করার জনে
function restore_product($product_id){
	Product::onlyTrashed()->find($product_id)->restore();
	return back();
}


	// ডিলিট করা ডাটাগুলে Permantly Delete করার জনে
function permantlyDeleteProduct($product_id){
// আপলোড করা ছবি গুলো একেবারে ডিলিট করার জনে
$delete_this_file = Product::onlyTrashed()->find($product_id)->Product_image;
unlink(base_path('public/uploads/product_photos/'.$delete_this_file));



	Product::onlyTrashed()->find($product_id)->forceDelete();
	return back();
}



    function addproductinsert(Request $request){
		// Form-Validation
		$request->validate([
			'categoryselectid' => 'required',
			'Product_Name_josim' => 'required',
			'Product_Description' => 'required',
			'Product_Price' => 'required|numeric',
			'Product_Quentity' => 'required|numeric',
			'Product_Alert_Quentity' => 'required|numeric',
		
		]);

// ইমেজ যোগ করা জনে $last_inserted_id = Product::insertGetId এটা দিতে হবে	
    	$last_inserted_id = Product::insertGetId([
   // Product_Name এটা টেবিলের কলামের নাম
// $request->Product_Name_josim, এটা টেবিলের input এর name="Product_Name_josim" থেকে আসছে
  			'category_p_id' => $request->categoryselectid,
			'Product_Name' => $request->Product_Name_josim,
    		'Product_Description' => $request->Product_Description,
    		'Product_Price' => $request->Product_Price,
    		'Product_Quentity' => $request->Product_Quentity,
    		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,
    	]);

       // ছবি আপলোডের জনে
    	// Image এটা আসছে Config থেকে
    	// Product_image এটা ফরমের ভিতরের input name
		
    	if($request->hasFile('Product_image')){
    		$photo_to_upload = $request->Product_image;
    		$filename = $last_inserted_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		Product::find($last_inserted_id)->update([
    			'Product_image' => $filename
    		]);

    		// 85 এটা ইমেজের MB টাকে ছোট করে দেই
    	}


			

    	return back()->with('status', 'Product Insert SuccessFully!');
    	// ডাটা Insert হলে SuccessFully message দেওয়ার জনে এবং যেখানে message
    	// দেখাবো মানে form এর মধে ও কিছু কাজ আছে

    	// এই মেথডের রাউট Route::post('/add/product/insert','ProductController@addproductinsert');
    }


	// ডাটা ডিলিট করার জন্যে

	function deleteproduct($product_id){
		Product::where('id', $product_id)->delete();
		return back()->with('deletestatus', 'Product Delete SuccessFully!');
	}


	// Edit করার সময় ডাটাগুলা শো করার জনে

	function editproduct($product_id){
		$single_product_info = Product::findOrFail($product_id);
		return view('Product.productedit', compact('single_product_info'));
	}



// Edit করে ডাটা যুকত করার জনে

function editproductinsert(Request $request){

	// ইমেজ আপডেট করার জনে
	if($request->hasFile('Product_image')){
		if(Product::find($request->product_id)->Product_image == 'defaultproductphoto.jpg'){



    		$photo_to_upload = $request->Product_image;
    		$filename = $request->product_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		Product::find($request->product_id)->update([
    			'Product_image' => $filename
    		]);

    		// 85 এটা ইমেজের MB টাকে ছোট করে দেই
    		// ডিফলট ছবির জায়গাতে নতুন আপলোড করা ছবিটি বসে যাবে


		}
		else{
			// এর কাজ হবে পুরান ছবি ডিলিট করে নতুন ছবি আপলোড করা
			// unlink এটা Laravel এর ডিফলট function যার মাধমে ছবিটা ডিলিট হয়ে যাবে

			$delete_this_file = Product::find($request->product_id)->Product_image;
			unlink(base_path('public/uploads/product_photos/'.$delete_this_file));

			// ডিলিট করার কোড উপরের টা আর নিচে দিব নতুন ছবি আপলোড করার জনে

			$photo_to_upload = $request->Product_image;
    		$filename = $request->product_id.".".$photo_to_upload->getClientOriginalExtension();
    		Image::make($photo_to_upload)->resize(400,450)->save(base_path('public/uploads/product_photos/'.$filename),85);
    		Product::find($request->product_id)->update([
    			'Product_image' => $filename
    		]);



		}


	}

	Product::find($request->product_id)->update([
		'Product_Name' => $request->Product_Name_josim,
		'Product_Description' => $request->Product_Description,
		'Product_Price' => $request->Product_Price,
		'Product_Quentity' => $request->Product_Quentity,
		'Product_Alert_Quentity' => $request->Product_Alert_Quentity,

	]);
	return back()->with('updatestatus', 'Product Update SuccessFully!');
}









}
